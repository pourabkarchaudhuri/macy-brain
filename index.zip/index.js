var dialogflowAPI = require('./dialogflow');
var searchAPI = require('./search');

var deasync = require('deasync');

exports.handler = (event, context, callback) => {
    // TODO implement
    console.log("Event : " + JSON.stringify(event));
    console.log("Context : " + JSON.stringify(context));

    let nluQueryClassifier = deasync(function(callback){
                   dialogflowAPI.callDialogflow(event, callback);
                 })();
    callback(null, nluQueryClassifier);
};
